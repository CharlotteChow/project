window.onload = function(){
	setTimeout(checkInput, 100);
}

history.pushState(null, null, document.URL);
window.addEventListener('popstate', function () {
        history.pushState(null, null, document.URL);
});

var submitBtn = document.getElementById("submit");

	submitBtn.onclick = function (event) {
	    checkInput();
	    return false;
	    
};

function login(url,name,password){
	var tips = document.getElementById('tips');
	$.ajax({
			type:"POST",
			dataType: "json",
	        headers: {
        		"Content-Type": "application/json"
    		},
    		contentType: "application/json",
	        url: url,
	        data:JSON.stringify({
				"user_code" : name,
				"user_key" : password
			}),
    		withCredentials: true,
			success:function(data){
				if(data.token == undefined){
					console.log(data);
					tips.innerHTML = "错误";
				}else{
					saveToken('token',data.token,1);
                	saveToken('user_id',data.user_id,1);
                	checkToken(data.token);
				}
	        },
	        error: function(msg){
	        	console.log(msg);
	        	console.log("fail");
	        }
	});
}

function checkInput(){//入口
	var _url = "http://202.116.163.200:11000/login";
	var name = document.getElementById("user_name").value;
	var password = document.getElementById("user_password").value;
	var tips = document.getElementById('tips');

	if((name == "") && (password =="")){
	 	checkCookie();
	}

	if((name == "" && (!password =="")) || (password == "" && (!name == ""))){
		tips.innerHTML = "填写不得为空!";
	}

	if(!(name == "" && password =="")){
		tips.innerHTML = "";
		login(_url,name,password);
	}

}

function checkToken(token){
	var _token = token;
	$.ajax({
	        url: "http://202.116.163.200:11000/root/query_user_list",
	        type: "POST",
	        beforeSend: function(request) {
	            request.setRequestHeader("token", _token);
	        },
	        success: function(result) {
				return true;
	        },
	        error: function(result) {
	        	console.log(result);
	        	return false;
	        }
	});
}

function checkCookie(){
	var token1 = getCookie("token");
	var token2 = getCookie("user_id");
	var tips = document.getElementById('tips');
	if (token1!=null && token1!=""){
			if (token2 == 1){
				window.location.href= "root.html";
			}else{
				window.location.href= "user.html";
			}
	}else{
		tips.innerHTML = "帐号登录超时，请重新登录!"
	}
}

function getCookie(name){ 
    var strCookie=document.cookie; 
    var arrCookie=strCookie.split(";"); 
    for(var i=0;i<arrCookie.length;i++){ 
          var arr=arrCookie[i].split("="); 
          if(arr[0].trim()==name)
          return arr[1];
    } 
    return ""; 
} 

// function saveToken(c_name,value,expiredays){
// 	console.log("saveToken");
// 	var exdate=new Date();
// 	exdate.setDate(exdate.getDate()+expiredays);
// 	document.cookie=c_name+ "=" +escape(value)+((expiredays==null) ? "" : ";expires="+exdate.toGMTString())
// }
function saveToken(c_name,value){
	console.log("saveToken");
	var exdate=new Date();
	exdate.setDate(exdate.getDate()+expiredays);
	document.cookie=c_name+ "=" +escape(value);
}
