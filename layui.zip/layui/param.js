var contents = [
	["temp", "&#8451", 0.01],
	["hump", "%", 0.01]
];// examples