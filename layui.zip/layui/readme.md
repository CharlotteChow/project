﻿# readme

---

 - 使用layui框架
 - 层次关系如下
    - custom.js （链接到login.html 文件，不包含其他html文件的代码）
    - login.html  
        -  user.html
            - param.html 
                - param_add.html
                - param.js (存储参数）
            - gateway.html
                - gateway_add.html
                - gateway_edit.html
                - gateway_show.html
            - project_edit.html
            - project_add.html
            - project_show.html
        -  root.html
            - user_add.html
    - test.json包含所有的测试数据
    
 - 注： 添加参数页面仍需手动添加选项

